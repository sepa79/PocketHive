# PocketHive – Generator (UI Overlay)

This archive adds a **Generator** UI to the existing PocketHive repository without overwriting your structure.
All strings, variables, and comments are in English.

## What’s included
- `ui/generator.html` — standalone Generator tab (Web‑STOMP over WSS).
- `ui/generator.css` — styles.
- `ui/generator.js` — logic (rate profiles, backpressure, metrics, p95).
- `ui/snippets/add_nav_link.html` — minimal HTML to add a menu link.
- `scripts/integrate-generator.ps1` — PowerShell helper to insert the nav link safely.
- `scripts/integrate-generator.sh` — Bash helper to insert the nav link safely.

## Quick usage (Windows/PowerShell)
1. Unzip this archive into the **repo root** (next to `ui/`, `generator-service/`, etc.).
2. Run:
   ```powershell
   ./scripts/integrate-generator.ps1
   ```
   The script will try to add a `<a href="generator.html">Generator</a>` link into `ui/index.html`:
   - It looks for a `<nav` ... `</nav>` block and inserts the link before `</nav>`.
   - If no `<nav>` is found, it appends a small floating button at the top-right of the page.

3. Commit and push:
   ```bash
   git add ui/ scripts/
   git commit -m "UI: add Generator tab (Web-STOMP)"
   git push
   ```

## Quick usage (macOS/Linux)
```bash
chmod +x scripts/integrate-generator.sh
scripts/integrate-generator.sh
```

## Manual link (if you prefer hand-edit)
Open `ui/index.html`, find your navbar, and add:
```html
<a href="generator.html">Generator</a>
```

## RabbitMQ notes
- Enable **Web‑STOMP** and expose **WSS** (typical: `wss://host:15674/ws`).
- Use a dedicated vhost/user for the browser client and prefer short‑lived tokens.
- If your UI is on HTTPS, WSS is required to avoid mixed‑content issues.

