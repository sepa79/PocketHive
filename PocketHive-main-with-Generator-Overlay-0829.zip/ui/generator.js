
/* PocketHive Browser Generator (STOMP over WebSocket) */
(() => {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  const fmt = (n) => Intl.NumberFormat().format(n);
  const kb = (b) => (b/1024).toFixed(1) + " KB";

  // ---- State ----
  let client = null;
  let connected = false;
  let sendTimer = null;
  let lastTick = 0;
  let sessionId = crypto.randomUUID();
  let resultQueuePrefix = "ph.results.";
  const inflight = new Map(); // correlationId => ts
  const metrics = {
    sent: 0, ack: 0, errors: 0, inFlight: 0,
    recv: 0, tStart: 0, lastSecSent: 0, lastSecRecv: 0,
    latency: { count:0, total:0, min:Infinity, max:0, p95:0 },
  };
  let latencySamples = [];

  // ---- UI helpers ----
  function log(msg) {
    const el = $("#log");
    el.textContent += msg + "\n";
    el.scrollTop = el.scrollHeight;
  }
  function setStatus(s, tone="off") {
    $("#status").textContent = s;
    const dot = $("#statusDot");
    dot.className = "dot " + tone;
  }
  function updateMetrics() {
    $("#mSent .big").textContent = fmt(metrics.sent);
    $("#mAck .big").textContent = fmt(metrics.ack);
    $("#mErr .big").textContent = fmt(metrics.errors);
    $("#mInFlight .big").textContent = fmt(metrics.inFlight);
    $("#mRecv .big").textContent = fmt(metrics.recv);

    const elapsed = (performance.now() - metrics.tStart) / 1000 || 1;
    $("#mRate .big").textContent = (metrics.sent / elapsed).toFixed(1);
    // Latency
    const L = metrics.latency;
    if (L.count > 0) {
      $("#mLatAvg .big").textContent = (L.total / L.count).toFixed(1) + " ms";
      $("#mLatMin .big").textContent = (L.min | 0) + " ms";
      $("#mLatMax .big").textContent = (L.max | 0) + " ms";
      $("#mLatP95 .big").textContent = (L.p95 | 0) + " ms";
    }
  }
  function syncSlider(id) {
    const range = $("#" + id);
    const out = $("#" + id + "Val");
    const number = $("#" + id + "Num");
    const set = (v) => {
      out.textContent = range.dataset.suffix ? (v + range.dataset.suffix) : v;
      number.value = v;
    };
    range.addEventListener("input", () => set(range.value));
    number.addEventListener("input", () => {
      const v = Number(number.value) || 0;
      range.value = Math.min(range.max, Math.max(range.min, v));
      set(range.value);
    });
    set(range.value);
  }

  // ---- Payload helpers ----
  function randomAscii(size) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_ .,:;!@#$%^&*()[]{}";
    let out = "";
    while (out.length < size) out += chars[Math.random()*chars.length|0];
    return out;
  }

  // ---- STOMP ----
  function connect() {
    if (connected) return;
    const brokerURL = $("#brokerUrl").value.trim();
    const vhost = $("#vhost").value.trim() || "/";
    const login = $("#login").value.trim();
    const passcode = $("#passcode").value.trim();
    if (!brokerURL || !login || !passcode) {
      log("Fill broker URL, login and passcode.");
      return;
    }
    if ($("#autoSession").checked) {
      sessionId = crypto.randomUUID();
      $("#session").textContent = sessionId;
    } else {
      sessionId = $("#sessionInput").value.trim() || sessionId;
      $("#session").textContent = sessionId;
    }
    resultQueuePrefix = $("#resPrefix").value.trim() || "ph.results.";

    // eslint-disable-next-line no-undef
    client = new StompJs.Client({
      brokerURL,
      connectHeaders: { login, passcode, host: vhost },
      reconnectDelay: Number($("#reconnectMs").value) || 0,
      debug: (s) => { if ($("#debug").checked) log("[DEBUG] " + s); }
    });

    client.onConnect = () => {
      connected = true;
      setStatus("connected", "ok");
      $("#btnConnect").disabled = true;
      $("#btnDisconnect").disabled = false;
      $("#btnSendOne").disabled = false;
      $("#btnStart").disabled = false;
      log("Connected.");

      // Subscribe results
      const q = resultQueuePrefix + sessionId;
      client.subscribe(`/queue/${q}`, onResult, { ack: "auto" });
      log(`Subscribed to /queue/${q}`);
    };

    client.onStompError = (frame) => {
      log("STOMP error: " + (frame.headers?.message || "") + "\n" + (frame.body || ""));
      setStatus("error", "err");
    };
    client.onWebSocketClose = () => {
      connected = false;
      setStatus("disconnected", "off");
      $("#btnConnect").disabled = false;
      $("#btnDisconnect").disabled = true;
      $("#btnSendOne").disabled = true;
      $("#btnStart").disabled = true;
      stopSending();
      log("Disconnected.");
    };

    setStatus("connecting...", "warn");
    client.activate();
  }

  function disconnect() {
    if (client) client.deactivate();
    client = null;
  }

  function onResult(message) {
    metrics.recv++;
    if (message && message.headers && message.headers["correlation-id"]) {
      const cid = message.headers["correlation-id"];
      const t0 = inflight.get(cid);
      if (t0) {
        const dt = performance.now() - t0;
        metrics.ack++;
        metrics.inFlight = Math.max(0, metrics.inFlight - 1);
        inflight.delete(cid);

        // latency stats
        const L = metrics.latency;
        L.count++;
        L.total += dt;
        L.min = Math.min(L.min, dt);
        L.max = Math.max(L.max, dt);
        latencySamples.push(dt);
        if (latencySamples.length > 2000) latencySamples.shift(); // cap
        // compute p95
        const s = [...latencySamples].sort((a,b)=>a-b);
        L.p95 = s[Math.floor(s.length*0.95)] || dt;
      }
    }
    if ($("#showJson").checked) {
      try {
        const obj = message.body ? JSON.parse(message.body) : {};
        log("Result:\n" + JSON.stringify(obj, null, 2));
      } catch {
        log("Result (raw): " + message.body);
      }
    }
    updateMetrics();
  }

  // ---- Sending loop ----
  function sendOne() {
    if (!client || !connected) { log("Not connected."); return; }
    const exchange = $("#exchange").value.trim() || "ph.jobs";
    const routingKey = $("#routingKey").value.trim() || "generator.request";
    const expectReply = $("#expectReply").checked;

    const payloadSize = Number($("#payloadBytes").value);
    const prompt = $("#prompt").value.trim();
    const nowIso = new Date().toISOString();
    const correlationId = crypto.randomUUID();
    const body = {
      type: "GENERATION_REQUEST",
      prompt,
      sessionId,
      correlationId,
      timestamp: nowIso,
      payload: payloadSize > 0 ? randomAscii(payloadSize) : undefined
    };

    const headers = { "content-type":"application/json", "correlation-id": correlationId };
    if (expectReply) headers["reply-to"] = (resultQueuePrefix + sessionId);

    try{
      client.publish({
        destination: `/exchange/${exchange}/${routingKey}`,
        body: JSON.stringify(body),
        headers
      });
      metrics.sent++;
      metrics.inFlight++;
      inflight.set(correlationId, performance.now());
      if (!metrics.tStart) metrics.tStart = performance.now();
    } catch (e) {
      metrics.errors++;
      log("Publish error: " + e.message);
    }
    updateMetrics();
  }

  function startSending() {
    if (sendTimer) return;
    metrics.tStart = performance.now();
    lastTick = performance.now();
    const mode = $("#mode").value; // constant|burst|poisson
    const concurrency = Number($("#concurrency").value);
    const rps = Number($("#rps").value);
    const burst = Number($("#burst").value);
    const jitter = Number($("#jitter").value)/100;
    const maxIn = Number($("#maxInflight").value);
    const backpressure = $("#backpressure").checked;
    const duration = Number($("#duration").value); // seconds, 0=infinite

    const tickMs = 100; // scheduler tick
    let elapsedSec = 0;
    let sentThisSec = 0;

    sendTimer = setInterval(() => {
      if (!client || !connected) return;
      const now = performance.now();
      const dt = now - lastTick;
      lastTick = now;
      elapsedSec += dt/1000;

      // stop by time
      if (duration > 0 && elapsedSec >= duration) {
        stopSending();
        return;
      }

      // backpressure guard
      if (backpressure && metrics.inFlight >= maxIn) return;

      // compute messages to send this tick
      let toSend = 0;
      if (mode === "constant") {
        // ideal per tick
        const base = rps * (dt/1000);
        // add jitter
        const j = jitter > 0 ? base * ( (Math.random()*2-1) * jitter ) : 0;
        toSend = Math.max(0, Math.round(base + j));
      } else if (mode === "burst") {
        // every second send a burst, idle otherwise
        if (Math.floor(elapsedSec) !== Math.floor(elapsedSec - dt/1000)) {
          toSend = burst;
        } else {
          toSend = 0;
        }
      } else if (mode === "poisson") {
        // Poisson arrivals: next event in exp(lambda=rps); approximate by chance per tick
        const p = Math.min(1, rps * (dt/1000));
        toSend = 0;
        for (let i=0;i<concurrency;i++){
          if (Math.random() < p) toSend++;
        }
      }

      // cap by remaining inflight capacity when backpressure
      if (backpressure && maxIn > 0) {
        const room = Math.max(0, maxIn - metrics.inFlight);
        toSend = Math.min(toSend, room);
      }

      // send * concurrency
      toSend = Math.max(0, toSend * Math.max(1, concurrency));

      for (let i=0;i<toSend;i++) sendOne();

      sentThisSec += toSend;
      // rolling per-sec log
      if (Math.floor(elapsedSec) !== Math.floor(elapsedSec - dt/1000)) {
        $("#rateNow").textContent = fmt(sentThisSec);
        sentThisSec = 0;
      }
    }, tickMs);

    $("#btnStart").disabled = true;
    $("#btnStop").disabled = false;
    setStatus("running", "ok");
  }

  function stopSending() {
    if (sendTimer) clearInterval(sendTimer);
    sendTimer = null;
    $("#btnStart").disabled = false;
    $("#btnStop").disabled = true;
    setStatus(connected ? "connected" : "disconnected", connected ? "ok" : "off");
  }

  function resetMetrics() {
    metrics.sent = 0; metrics.ack = 0; metrics.errors = 0; metrics.inFlight = inflight.size;
    metrics.recv = 0; metrics.tStart = performance.now(); metrics.lastSecSent = 0; metrics.lastSecRecv = 0;
    metrics.latency = { count:0, total:0, min:Infinity, max:0, p95:0 };
    latencySamples = [];
    updateMetrics();
  }

  // ---- Bindings ----
  window.addEventListener("DOMContentLoaded", () => {
    $("#session").textContent = sessionId;
    syncSlider("rps");
    syncSlider("burst");
    syncSlider("payloadBytes");
    syncSlider("concurrency");
    syncSlider("maxInflight");
    syncSlider("jitter");
    syncSlider("duration");

    $("#btnConnect").addEventListener("click", connect);
    $("#btnDisconnect").addEventListener("click", disconnect);
    $("#btnSendOne").addEventListener("click", sendOne);
    $("#btnStart").addEventListener("click", startSending);
    $("#btnStop").addEventListener("click", stopSending);
    $("#btnReset").addEventListener("click", resetMetrics);

    // session edit toggle
    $("#autoSession").addEventListener("change", () => {
      const on = $("#autoSession").checked;
      $("#sessionInput").classList.toggle("hidden", on);
    });
  });
})();
