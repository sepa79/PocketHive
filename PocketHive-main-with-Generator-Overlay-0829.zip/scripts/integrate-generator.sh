#!/usr/bin/env bash
set -euo pipefail
INDEX_PATH="${1:-ui/index.html}"
echo "[PocketHive] Integrating Generator link into ${INDEX_PATH}"

if [[ ! -f "${INDEX_PATH}" ]]; then
  echo "File not found: ${INDEX_PATH}" >&2
  exit 1
fi

if grep -q 'href=["'\'']generator\.html["'\'']' "${INDEX_PATH}"; then
  echo "Generator link already present. Nothing to do."
  exit 0
fi

# Try to insert before </nav> (first occurrence)
if grep -q '</nav>' "${INDEX_PATH}"; then
  tmp="$(mktemp)"
  awk '
    BEGIN{inserted=0}
    /<\/nav>/ && !inserted {
      print "  <a href=\"generator.html\">Generator</a>"
      inserted=1
    }
    { print }
  ' "${INDEX_PATH}" > "$tmp"
  mv "$tmp" "${INDEX_PATH}"
  echo "Inserted link into existing <nav>."
else
  # Fallback: floating button
  tmp="$(mktemp)"
  cat > "$tmp" <<'EOF'
<style>
#ph-gen-fab{position:fixed;top:12px;right:12px;z-index:9999;background:#ffc107;color:#111;
  border:1px solid #e5b000;border-radius:999px;padding:8px 12px;font-family:sans-serif;text-decoration:none}
#ph-gen-fab:hover{filter:brightness(0.95)}
</style>
<a id="ph-gen-fab" href="generator.html" title="Open Generator">Generator</a>
EOF
  cat "${INDEX_PATH}" >> "$tmp"
  mv "$tmp" "${INDEX_PATH}"
  echo "No <nav> found. Added a floating 'Generator' button."
fi

echo "Done."
