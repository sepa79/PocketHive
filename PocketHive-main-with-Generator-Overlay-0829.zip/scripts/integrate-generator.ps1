Param(
  [string]$IndexPath = "ui/index.html"
)

Write-Host "[PocketHive] Integrating Generator link into $IndexPath"

if (!(Test-Path $IndexPath)) {
  Write-Warning "File not found: $IndexPath. Aborting."
  exit 1
}

$content = Get-Content -Path $IndexPath -Raw

# If link already exists, bail out
if ($content -match 'href\s*=\s*["'']generator\.html["'']') {
  Write-Host "Generator link already present. Nothing to do."
  exit 0
}

# Try to find a <nav>...</nav> block
$navPattern = '(?s)(<nav\b[^>]*>)(.*?)(</nav>)'
$hasNav = [System.Text.RegularExpressions.Regex]::IsMatch($content, $navPattern)

$link = '<a href="generator.html">Generator</a>'

if ($hasNav) {
  $newContent = [System.Text.RegularExpressions.Regex]::Replace($content, $navPattern, {
    param($m)
    return $m.Groups[1].Value + $m.Groups[2].Value + "`n  " + $link + $m.Groups[3].Value
  }, 1)

  Set-Content -Path $IndexPath -Value $newContent -Encoding UTF8
  Write-Host "Inserted link into existing <nav>."
} else {
  # Fallback: add a floating button at the top‑right
  $inject = @"
<style>
#ph-gen-fab{position:fixed;top:12px;right:12px;z-index:9999;background:#ffc107;color:#111;
  border:1px solid #e5b000;border-radius:999px;padding:8px 12px;font-family:sans-serif;text-decoration:none}
#ph-gen-fab:hover{filter:brightness(0.95)}
</style>
<a id="ph-gen-fab" href="generator.html" title="Open Generator">Generator</a>
"@

  $newContent = $inject + "`n" + $content
  Set-Content -Path $IndexPath -Value $newContent -Encoding UTF8
  Write-Host "No <nav> found. Added a floating 'Generator' button."
}

Write-Host "Done."
