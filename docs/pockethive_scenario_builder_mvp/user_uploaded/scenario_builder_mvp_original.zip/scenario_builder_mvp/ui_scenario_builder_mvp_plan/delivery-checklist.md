
# Delivery Checklist

- [ ] Module Federation wiring and route registered in shell
- [ ] JSON Schema co-published in both UI and Scenario Manager repos
- [ ] Feature flag `scenarioBuilder.enabled`
- [ ] Docs page linked in main UI
