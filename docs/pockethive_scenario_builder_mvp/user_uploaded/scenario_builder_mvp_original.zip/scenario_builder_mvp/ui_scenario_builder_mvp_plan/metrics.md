
# Telemetry (MVP)

- `scenario.save.success|failure`
- `scenario.apply.clicked`
- `timeline.blocks.count`
- `validation.errors.count`
