
# Routes

- `/scenario` — list scenarios
- `/scenario/new` — new scenario
- `/scenario/edit/:id` — edit scenario
- `/scenario/runs` — runs list
- `/scenario/runs/:runId` — run details
