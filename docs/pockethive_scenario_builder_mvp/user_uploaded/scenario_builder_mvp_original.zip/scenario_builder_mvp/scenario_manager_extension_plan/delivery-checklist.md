
# Delivery Checklist

- [ ] JSON Schema published and versioned
- [ ] CRUD + validation endpoints live
- [ ] Apply endpoints returning runId
- [ ] Run status read model exposed
- [ ] E2E with Orchestrator happy path
