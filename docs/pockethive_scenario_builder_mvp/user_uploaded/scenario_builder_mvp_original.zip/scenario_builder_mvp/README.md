# Orchestrator → Controller Contract (v0)
Generated: 2025-09-29T13:13:52.272379Z

This pack defines the bare-minimum messaging contract between Orchestrator and Swarm Controller.

Files:
- `contract.md`
- `sequences/orchestrator-controller.mmd`
- `examples/plan-example.json`
- `tests/contract-conformance.md`
